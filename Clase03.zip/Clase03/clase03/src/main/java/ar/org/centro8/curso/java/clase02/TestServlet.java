package ar.org.centro8.curso.java.clase02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="test", urlPatterns = "/test")
public class TestServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        //http://localhost:8080/test
        //response.setContentType("text/plain");
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        out.println("<h1>Hola Mundo Servlet!</h1>");
        out.println("<h2>Aplicaciones Web!</h2>");

        //Ingreso de párametros de usuario
        //http://localhost:8080/test?nombre=Carlos
        String nombre=request.getParameter("nombre");
        System.out.println(nombre.length());
        if(nombre!=null && !nombre.isEmpty()){
            out.println("<h2>Hola "+nombre+"</h2>");
        }

        //Tema pendiente cliente http

        //Normalización de direcciones buenos aires
        //http://servicios.usig.buenosaires.gob.ar/normalizar

    }

}
