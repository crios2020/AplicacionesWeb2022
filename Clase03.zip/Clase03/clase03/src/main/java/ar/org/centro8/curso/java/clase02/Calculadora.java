package ar.org.centro8.curso.java.clase02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="calculadora", urlPatterns = "/calculadora")
public class Calculadora extends HttpServlet {
    
    private void doRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //http://localhost:8080/calculadora?nro1=5&nro2=9
        
        PrintWriter out = response.getWriter();
        try {
            int nro1=Integer.parseInt(request.getParameter("nro1"));
            int nro2=Integer.parseInt(request.getParameter("nro2"));
            int resultado=nro1+nro2;
            out.println(resultado);
        } catch (Exception e) {
            out.println("error");
        }

        //TEmas pendientes 
        // LOGIN solo POST
        // DAO Servlet Clientes
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doRequest(request, response);
    }
}
