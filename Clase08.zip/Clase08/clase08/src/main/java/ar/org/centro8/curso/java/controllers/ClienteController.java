package ar.org.centro8.curso.java.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.curso.java.data.services.ClienteDataService;
import ar.org.centro8.curso.java.entities.Cliente;

@RestController
@RequestMapping("/clientes")
public class ClienteController {
    
    @GetMapping()
    public String info(){
        return "Servicio alumnos Activo";
    }

}
