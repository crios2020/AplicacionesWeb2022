package ar.org.centro8.curso.java.repositories.jdbc;

import java.util.List;

import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.repositories.interfaces.I_ClienteRepository;

public class ClienteRepository implements I_ClienteRepository{

    @Override
    public void save(Cliente cliente) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void delete(Cliente cliente) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<Cliente> getAll() {
        // TODO Auto-generated method stub
        return null;
    }
    
}
