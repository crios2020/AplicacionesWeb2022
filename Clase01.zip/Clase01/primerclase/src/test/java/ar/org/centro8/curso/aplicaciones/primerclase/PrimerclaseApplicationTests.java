package ar.org.centro8.curso.aplicaciones.primerclase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerclaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
