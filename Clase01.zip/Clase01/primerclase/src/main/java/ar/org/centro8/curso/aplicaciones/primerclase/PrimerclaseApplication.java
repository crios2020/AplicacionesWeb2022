package ar.org.centro8.curso.aplicaciones.primerclase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerclaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerclaseApplication.class, args);
		System.out.println("Hola Mundo Springboot!!!!");
	}

}
